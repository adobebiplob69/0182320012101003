
import 'package:flutter/material.dart';

class CartPage extends StatelessWidget {
  const CartPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Cart"), backgroundColor: Color(0xFFE21B70)),
      body: Column(
        children: [
          ListTile(title: Text("Burger Combo"), trailing: Text("৳350")),
          Spacer(),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: Color(0xFFE21B70)),
            child: Text("Proceed to Payment"),
            onPressed: () {
              showModalBottomSheet(
                context: context,
                builder: (_) => Column(
                  mainAxisSize: MainAxisSize.min,
                  children: const [
                    ListTile(title: Text("Cash on Delivery")),
                    ListTile(title: Text("Card Payment")),
                  ],
                ),
              );
            },
          )
        ],
      ),
    );
  }
}
