
import 'package:flutter/material.dart';

class ProfilePage extends StatelessWidget {
  const ProfilePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Profile"), backgroundColor: Color(0xFFE21B70)),
      body: ListView(
        children: const [
          ListTile(leading: Icon(Icons.admin_panel_settings), title: Text("Admin Panel")),
          ListTile(leading: Icon(Icons.history), title: Text("Order History")),
        ],
      ),
    );
  }
}
