
import 'package:flutter/material.dart';

class OrdersPage extends StatelessWidget {
  const OrdersPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Orders"), backgroundColor: Color(0xFFE21B70)),
      body: Stepper(
        currentStep: 1,
        steps: const [
          Step(title: Text("Preparing"), content: Text("Cooking food")),
          Step(title: Text("On the way"), content: Text("Rider coming")),
          Step(title: Text("Delivered"), content: Text("Enjoy!")),
        ],
      ),
    );
  }
}
