
import 'package:flutter/material.dart';

class HomePage extends StatelessWidget {
  const HomePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(backgroundColor: Color(0xFFE21B70), title: Text("Foodpanda")),
      body: GridView.builder(
        padding: EdgeInsets.all(12),
        gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 2, childAspectRatio: .75),
        itemCount: 100,
        itemBuilder: (c, i) => Card(
          child: Column(
            children: [
              Expanded(
                child: Image.network(
                  "https://images.unsplash.com/photo-1600891964599-f61ba0e24092",
                  fit: BoxFit.cover,
                ),
              ),
              Padding(
                padding: EdgeInsets.all(6),
                child: Text("Food Item ${i+1}"),
              )
            ],
          ),
        ),
      ),
    );
  }
}
